#include <pcl/point_cloud.h>
#include <pcl/point_types.h>
#include <pcl/io/pcd_io.h>
#include <boost/filesystem/path.hpp>
#include <boost/filesystem.hpp>

#include <object_recognition.h>

bool compareName(const std::string& p_object, const std::string& p_result)
{
    bool validation = true;

    int size = p_object.size();
    if(p_result.size() < size)
    {
        size = p_result.size();
    }

    for(int i = 0; i < size; i++)
    {
        if(p_object[i] == '_' || p_result[i] == '_')
        {
            break;
        }
        else if(p_object[i] == p_result[i])
        {
            validation = true;
        }
        else
        {
            validation = false;
            break;
        }
    }

    return validation;

}

float calculatePercentage(std::vector<bool> p_vector)
{
    int compteurTrue = 0;
    for(int i = 0; i < p_vector.size(); i++)
    {
        if(p_vector[i])
        {
            compteurTrue++;
        }
    }
    float percentage = ((float)compteurTrue/p_vector.size());
    percentage = percentage*100;
    return percentage;
}

void oneLoop(const std::string& p_cvfhSignature, const std::string& p_object, int p_thresold)
{
    std::stringstream ss;
    ss << p_object << "/log_" << p_thresold << ".txt";
    std::string saveFile = ss.str();
    std::ofstream ofs(saveFile.c_str());

    std::vector<bool> confirmationVector;

    boost::filesystem3::path pathObject(p_object);
    boost::filesystem3::recursive_directory_iterator dirItObject(pathObject);

    while(dirItObject != boost::filesystem3::recursive_directory_iterator())
    {
        boost::filesystem3::path pathObjectTemp;
        pathObjectTemp = * dirItObject;

        if(pathObjectTemp.extension() == ".pcd" and ! boost::filesystem3::is_directory(pathObjectTemp))
        {
            //boost::filesystem3::path bdPath(BDPATH);
            //boost::filesystem3::recursive_directory_iterator dirItdb(bdPath);

            //boost::filesystem3::path fullScanPath(FULLSCANPATH);
            //boost::filesystem3::directory_iterator dirItScan(fullScanPath);

            boost::filesystem3::path signatureBd(p_cvfhSignature);
            boost::filesystem3::recursive_directory_iterator dirItSignature(signatureBd);


            std::vector<std::string> nameVector;
            std::vector<int> signatureVector;
            pcl::PointCloud<pcl::VFHSignature308>::Ptr signatureCloud_ptr(new pcl::PointCloud<pcl::VFHSignature308>);

            boost::filesystem3::path pathTemp;
            //populate the signature cloud
            while(dirItSignature != boost::filesystem3::recursive_directory_iterator())
            {
                pathTemp  = * dirItSignature;
                if(!boost::filesystem3::is_directory(pathTemp) and pathTemp.extension() == ".pcd" && pathTemp.filename() != pathObjectTemp.filename())
                {
                    pcl::PointCloud<pcl::VFHSignature308> tempCloud;
                    pcl::io::loadPCDFile(pathTemp.c_str(), tempCloud);
                    for(int i = 0; i < tempCloud.size(); i ++)
                    {
                        signatureCloud_ptr->push_back(tempCloud.at(i));
                        nameVector.push_back(pathTemp.stem().c_str());
                    }
                }

                dirItSignature++;
            }

            Object_recognition objectRecon;


            pcl::PointCloud<pcl::PointXYZRGB>::Ptr loadedCloud(new pcl::PointCloud<pcl::PointXYZRGB>);
            pcl::io::loadPCDFile(pathObjectTemp.c_str(), *loadedCloud);

            pcl::PointCloud<pcl::VFHSignature308>::Ptr signatureLoaded_ptr(new pcl::PointCloud<pcl::VFHSignature308>);
            signatureLoaded_ptr = objectRecon.makeCVFH(loadedCloud);

            std::vector<float> vectorResult;
            vectorResult = objectRecon.histogramComparisonVector(signatureLoaded_ptr,signatureCloud_ptr);

            std::cout << "the object is -> " << nameVector.at(vectorResult[0]) << std::endl;

            bool confir = compareName(pathObjectTemp.stem().c_str(), nameVector.at(vectorResult[0]));

            float score = vectorResult[1];

            if(confir and score < p_thresold)
            {
                confirmationVector.push_back(true);
            }
            else
            {
                confirmationVector.push_back(false);
            }
            ofs << "Surface test :  " << pathObjectTemp.stem().c_str() << std::endl;
            ofs << "Best mathc :  " << nameVector.at(vectorResult[0]) << std::endl;
            ofs << "Distance :  " << vectorResult[1] << std::endl;
            ofs << "Confirmation :  " <<  confir << std::endl;
            ofs << "------------------------" << std::endl;
        }
        dirItObject++;
    }
    float percentage = calculatePercentage(confirmationVector);
    std::cout << "The percentage is " << percentage << "%" << std::endl;
    ofs << "The recognition percentage is : " << percentage << "%" << std::endl;
    ofs.close();
}



int main(int argc, char** argv)
{

    //std::string BDPATH = argv[1];
    //std::string FULLSCANPATH = argv[2];
    std::string CVFHSIGNATUREPATH = argv[1];
    std::string OBJECTLOAD = argv[2];
    std::vector<int> vectorThresold;
    vectorThresold.push_back(10000);
    vectorThresold.push_back(20000);
    vectorThresold.push_back(50000);
    vectorThresold.push_back(100000);
    vectorThresold.push_back(500000);
    vectorThresold.push_back(1000000);
    for(int i = 0; i < vectorThresold.size(); i++)
    {
        oneLoop(CVFHSIGNATUREPATH, OBJECTLOAD, vectorThresold[i]);
    }
    return 0;
}
